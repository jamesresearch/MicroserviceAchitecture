﻿using CartDomain.Interfaces;
using CartDomain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CartInfrastructure.Data
{
    public class ItemRepository : IItemRepository
    {
        private readonly CartDbContext _cartDbContext;
        private readonly DbSet<Item> _items;
        public ItemRepository(CartDbContext cartDbContext)
        {
            _cartDbContext = cartDbContext;
            _items = _cartDbContext.Set<Item>();
        }
        public void AddItem(Item item)
        {
            _items.Add(item);
        }

        public void DeleteItem(Item item)
        {
            _items.Remove(item);
        }

        public int SaveChanges()
        {
            return _cartDbContext.SaveChanges();
        }
    }
}
