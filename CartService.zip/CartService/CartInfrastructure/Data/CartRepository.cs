﻿using CartDomain.Interfaces;
using CartDomain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace CartInfrastructure.Data
{
    public class CartRepository : ICartRepository
    {
        private readonly CartDbContext _cartDbContext;
        private readonly DbSet<Cart> _carts;
        public CartRepository(CartDbContext dbContext)
        {
            _cartDbContext = dbContext;
            _carts = _cartDbContext.Set<Cart>();
        }

        public void AddCart(Cart cart)
        {
            _carts.Add(cart);
        }

        public Cart GetCartById(Guid cartId)
        {
            return _carts.Include(a => a.Items).FirstOrDefault(a => a.Id == cartId);
        }

        public int SaveChanges()
        {
            return _cartDbContext.SaveChanges();
        }

    }

}
