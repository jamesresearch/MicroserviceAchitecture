﻿using System;
using Microsoft.EntityFrameworkCore;
using CartDomain.Models;

namespace CartInfrastructure.Data
{
    public partial class CartDbContext : DbContext
    {
        public CartDbContext()
        {
        }

        public CartDbContext(DbContextOptions<CartDbContext> options)  : base(options)
        {
        }

        public virtual DbSet<Cart> TblCart { get; set; }
        public virtual DbSet<Item> TblItem { get; set; }

    }
}
