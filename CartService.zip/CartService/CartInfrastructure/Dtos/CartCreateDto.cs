﻿using System;

namespace CartInfrastructure.Dtos
{
    public class CartCreateDto
    {
        public Guid Id { get; set; }

    }
}
