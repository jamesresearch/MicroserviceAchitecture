﻿using System;
using System.Collections.Generic;

namespace CartInfrastructure.Dtos
{
    public class CartReadDto
    {
        public Guid Id { get; set; }
        public virtual ICollection<ItemReadDto> Items { get; set; }

    }
}
