﻿using Azure.Messaging.ServiceBus;
using CartDomain.Interfaces;
using CartDomain.Models;
using System;
using System.Threading.Tasks;

namespace CartInfrastructure.Publishers
{
    public class MessagePublisher : IMessagePublisher
    {
        private readonly ServiceBusClient _serviceBusClient;
        private readonly ServiceBusSender _serviceBusSender;
        public MessagePublisher(ServiceBusClient serviceBusClient, ServiceBus serviceBus)
        {
            _serviceBusClient = serviceBusClient;
            _serviceBusSender = _serviceBusClient.CreateSender(serviceBus.TopicName);
        }

        public async Task Publish(string subject)
        {
            if (!string.IsNullOrEmpty(subject))
            {
                ServiceBusMessage message = new ServiceBusMessage()
                {
                    Subject = subject
                };

                await _serviceBusSender.SendMessageAsync(message);
            }
            else
            {
                throw new ArgumentException("Parameter subject not provided");
            }
        }
    }
}
