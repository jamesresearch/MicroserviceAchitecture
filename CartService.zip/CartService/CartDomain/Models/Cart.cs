﻿using System;
using System.Collections.Generic;

namespace CartDomain.Models
{
    public partial class Cart
    {
        public Cart()
        {
            Items = new List<Item>();
        }

        public Guid Id { get; set; }

        public virtual ICollection<Item> Items { get; set; }
    }
}
