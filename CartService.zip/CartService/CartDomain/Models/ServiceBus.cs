﻿namespace CartDomain.Models
{
    public class ServiceBus
    {
        public string TopicName { get; set; }
    }
}
