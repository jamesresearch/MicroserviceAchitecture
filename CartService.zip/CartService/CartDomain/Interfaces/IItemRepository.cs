﻿using CartDomain.Models;

namespace CartDomain.Interfaces
{
    public interface IItemRepository
    {
        public void AddItem(Item item);
        public void DeleteItem(Item item);
        public int SaveChanges();
    }
}
