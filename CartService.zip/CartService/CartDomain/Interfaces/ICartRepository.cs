﻿using CartDomain.Models;
using System;

namespace CartDomain.Interfaces
{
    public interface ICartRepository
    {
        public void AddCart(Cart cart);
        public Cart GetCartById(Guid cartId);
        public int SaveChanges();
    }
}
