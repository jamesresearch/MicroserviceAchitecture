﻿using System.Threading.Tasks;

namespace CartDomain.Interfaces
{
    public interface IMessagePublisher
    {
        public Task Publish(string subject);
    }
}
