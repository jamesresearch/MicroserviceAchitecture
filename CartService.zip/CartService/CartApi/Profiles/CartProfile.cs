﻿using AutoMapper;
using CartInfrastructure.Dtos;
using CartDomain.Models;

namespace CartApi.Profiles
{
    public class CartProfile : Profile
    {
        public CartProfile()
        {
            CreateMap<Cart, CartReadDto>();

            CreateMap<ItemReadDto, Item>();
            CreateMap<Item, ItemReadDto>();

            CreateMap<Item, ItemCreateDto>();
            CreateMap<ItemCreateDto, Item>();
        }
    }
}
