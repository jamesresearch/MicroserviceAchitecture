﻿using AutoMapper;
using CartInfrastructure.Dtos;
using CartDomain.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using CartDomain.Interfaces;

namespace CartApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartRepository _cartRepository;
        private readonly IItemRepository _itemRepository;
        private readonly IMessagePublisher _messagePublisher;
        private readonly IMapper _mapper;
        public CartController(ICartRepository cartRepository, IItemRepository itemRepository, IMessagePublisher messagePublisher, 
            IMapper mapper)
        {
            _cartRepository = cartRepository;
            _itemRepository = itemRepository;
            _messagePublisher = messagePublisher;
            _mapper = mapper;
        }

        [HttpGet("{cartId}", Name = "GetCartById")]
        public ActionResult<CartReadDto> GetCartById(string cartId)
        {
            if (!string.IsNullOrEmpty(cartId))
            {
                Cart result = _cartRepository.GetCartById(new Guid(cartId));

                if (result != null)
                {
                    return Ok(_mapper.Map<CartReadDto>(result));
                }

                return NotFound("CartId not found");
            }

            return BadRequest("CartId parameter not provided");
        }

        [HttpPost]
        public ActionResult<ItemReadDto> AddItemToCart(ItemCreateDto item)
        {
            if (item != null)
            {
                _itemRepository.AddItem(_mapper.Map<Item>(item));
                _itemRepository.SaveChanges();
                _messagePublisher.Publish("Item added to cart");
                return Ok();
            }

            return BadRequest("Item parameter not provided");
        }

    }

}

