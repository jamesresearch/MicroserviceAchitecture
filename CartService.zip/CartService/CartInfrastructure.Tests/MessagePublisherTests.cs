using Azure.Messaging.ServiceBus;
using CartDomain.Models;
using CartInfrastructure.Publishers;
using Moq;
using System;
using Xunit;

namespace CartInfrastructure.Tests
{
    public class MessagePublisherTests
    {
        private readonly MessagePublisher messagePublisher = null;
        private readonly Mock<ServiceBusClient> serviceBusClient;
        private readonly Mock<ServiceBusSender> serviceBusSender;

        private readonly string emptySubject = string.Empty;
        private readonly string nonEmptySubject = "subject";
        private readonly string errorMessage = "Parameter subject not provided";

        private readonly string topicName = "Topic name";
        private readonly ServiceBus serviceBus = new ServiceBus();

        public MessagePublisherTests()
        {
            this.serviceBus.TopicName = topicName;
            this.serviceBusSender = new Mock<ServiceBusSender>();
            this.serviceBusClient = new Mock<ServiceBusClient>();
            this.serviceBusClient.Setup(a => a.CreateSender(topicName)).Returns(serviceBusSender.Object);
            this.messagePublisher = new MessagePublisher(serviceBusClient.Object, serviceBus);
        }

        [Fact]
        public async void Publish_SubjectIsEmpty_ExceptionThrown()
        {
            ArgumentException exception = await Assert.ThrowsAsync<ArgumentException>(() =>
                messagePublisher.Publish(emptySubject));
            Assert.Equal(errorMessage, exception.Message);

            serviceBusClient.Verify(a => a.CreateSender(topicName), Times.Once);
            serviceBusClient.VerifyNoOtherCalls();
        }

        [Fact]
        public async void Publish_SubjectProvided_MessageSent()
        {
            ServiceBusMessage message = new ServiceBusMessage()
            {
                Subject = nonEmptySubject
            };

            await messagePublisher.Publish(nonEmptySubject);

            serviceBusSender.Verify(a => a.SendMessageAsync(It.Is<ServiceBusMessage>(b => b.Subject == nonEmptySubject),
                It.IsAny<System.Threading.CancellationToken>()), Times.Once);
            serviceBusClient.Verify(a => a.CreateSender(topicName), Times.Once);
            serviceBusClient.VerifyNoOtherCalls();
        }
    }
}
