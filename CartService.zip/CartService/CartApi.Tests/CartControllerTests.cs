using AutoMapper;
using CartDomain.Interfaces;
using CartDomain.Models;
using CartInfrastructure.Dtos;
using CartApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace CartApi.Tests
{
    public class CartControllerTests
    {
        private readonly CartController cartController = null;
        private readonly Mock<ICartRepository> cartRepository;
        private readonly Mock<IItemRepository> itemRepository;
        private readonly Mock<IMessagePublisher> messagePublisher;
        private readonly Mock<IMapper> mapper;

        private readonly string emptyCartId;
        private readonly string nonEmptyCartId;
        private readonly Cart emptyCart;
        private readonly Cart nonEmptyCart;
        private readonly CartReadDto nonEmptyCartDto;
        private readonly Item nonEmptyItem;
        private readonly Item nonEmptyItemNoId;
        private readonly ItemCreateDto emptyItemCreateDto;
        private readonly ItemCreateDto nonEmptyItemCreateDto;

        public CartControllerTests()
        {
            this.cartRepository = new Mock<ICartRepository>();
            this.itemRepository = new Mock<IItemRepository>();
            this.messagePublisher = new Mock<IMessagePublisher>();
            this.mapper = new Mock<IMapper>();
            this.cartController = new CartController(cartRepository.Object, itemRepository.Object, messagePublisher.Object, 
                mapper.Object);

            this.emptyCartId = string.Empty;
            this.nonEmptyCartId = Guid.NewGuid().ToString();
            this.emptyCart = null;
            this.nonEmptyCart = new Cart()
            {
                Id = Guid.NewGuid(),
                Items = new List<Item>()
            };
            this.nonEmptyCartDto = new CartReadDto()
            {
                Id = this.nonEmptyCart.Id,
                Items = new List<ItemReadDto>()
            };
            this.nonEmptyItem = new Item()
            {
                CartId = new Guid(nonEmptyCartId),
                Id = Guid.NewGuid(),
                ImageName = "iPhone 13 Pro.jpg",
                Name = "iPhone 13 Pro",
                Price = 1099.99,
                Quantity = 2,
                ProductId = Guid.NewGuid()
            };
            this.nonEmptyItemNoId = new Item()
            {
                CartId = new Guid(nonEmptyCartId),
                ImageName = "iPhone 13 Pro.jpg",
                Name = "iPhone 13 Pro",
                Price = 1099.99,
                Quantity = 2,
                ProductId = Guid.NewGuid()
            };

            this.nonEmptyItemCreateDto = new ItemCreateDto()
            {
                CartId = new Guid(nonEmptyCartId),
                ImageName = "iPhone 13 Pro.jpg",
                Name = "iPhone 13 Pro",
                Price = 1099.99,
                Quantity = 2,
                ProductId = nonEmptyItem.ProductId
            };
        }

        [Fact]
        public void GetCartById_CartIdIsEmpty_BadRequestReturned()
        {
            BadRequestObjectResult badRequestObjectResult = new BadRequestObjectResult("CartId parameter not provided");

            ActionResult<CartReadDto> realActionResult = cartController.GetCartById(emptyCartId);

            BadRequestObjectResult realBadRequestObjectResult = Assert.IsType<BadRequestObjectResult>(realActionResult.Result);
            Assert.Equal(badRequestObjectResult.StatusCode, realBadRequestObjectResult.StatusCode);
            Assert.Equal(badRequestObjectResult.Value, realBadRequestObjectResult.Value);

            cartRepository.VerifyNoOtherCalls();
            itemRepository.VerifyNoOtherCalls();
            messagePublisher.VerifyNoOtherCalls();
            mapper.VerifyNoOtherCalls();
        }

        [Fact]
        public void GetCartById_CartReturnedIsNull_NotFoundReturned()
        {
            NotFoundObjectResult notFoundObjectResult = new NotFoundObjectResult("CartId not found");
            cartRepository.Setup(a => a.GetCartById(new Guid(nonEmptyCartId))).Returns(emptyCart);

            ActionResult<CartReadDto> realActionResult = cartController.GetCartById(nonEmptyCartId);

            NotFoundObjectResult realNotFoundObjectResult = Assert.IsType<NotFoundObjectResult>(realActionResult.Result);
            Assert.Equal(notFoundObjectResult.StatusCode, realNotFoundObjectResult.StatusCode);
            Assert.Equal(notFoundObjectResult.Value, realNotFoundObjectResult.Value);

            cartRepository.Verify(a => a.GetCartById(new Guid(nonEmptyCartId)), Times.Once);
            cartRepository.VerifyNoOtherCalls();
            itemRepository.VerifyNoOtherCalls();
            messagePublisher.VerifyNoOtherCalls();
            mapper.VerifyNoOtherCalls();
        }

        [Fact]
        public void GetCartById_CartReturned_OkReturned()
        {
            OkObjectResult okObjectGlobalResult = new OkObjectResult(nonEmptyCart);

            cartRepository.Setup(a => a.GetCartById(new Guid(nonEmptyCartId))).Returns(nonEmptyCart);
            mapper.Setup(a => a.Map<CartReadDto>(nonEmptyCart)).Returns(nonEmptyCartDto);

            ActionResult<CartReadDto> realActionResult = cartController.GetCartById(nonEmptyCartId);

            OkObjectResult okObjectResult = Assert.IsType<OkObjectResult>(realActionResult.Result);

            Assert.Equal(okObjectGlobalResult.StatusCode, okObjectResult.StatusCode);
            Assert.Same(nonEmptyCartDto, okObjectResult.Value);

            cartRepository.Verify(a => a.GetCartById(new Guid(nonEmptyCartId)), Times.Once);
            cartRepository.VerifyNoOtherCalls();
            itemRepository.VerifyNoOtherCalls();
            messagePublisher.VerifyNoOtherCalls();
            mapper.Verify(a => a.Map<CartReadDto>(nonEmptyCart), Times.Once);
            mapper.VerifyNoOtherCalls();
        }

        [Fact]
        public void AddItemToCart_ItemNotProvided_BadRequestReturned()
        {
            BadRequestObjectResult badRequestObjectResult = new BadRequestObjectResult("Item parameter not provided");

            ActionResult<ItemReadDto> realActionResult = cartController.AddItemToCart(emptyItemCreateDto);

            BadRequestObjectResult realBadRequestObjectResult = Assert.IsType<BadRequestObjectResult>(realActionResult.Result);
            Assert.Equal(badRequestObjectResult.StatusCode, realBadRequestObjectResult.StatusCode);
            Assert.Equal(badRequestObjectResult.Value, realBadRequestObjectResult.Value);

            cartRepository.VerifyNoOtherCalls();
            itemRepository.VerifyNoOtherCalls();
            messagePublisher.VerifyNoOtherCalls();
            mapper.VerifyNoOtherCalls();
        }

        [Fact]
        public void AddItemToCart_ItemProvided_OkReturned()
        {
            mapper.Setup(a => a.Map<Item>(nonEmptyItemCreateDto)).Returns(nonEmptyItemNoId);

            ActionResult<ItemReadDto> realActionResult = cartController.AddItemToCart(nonEmptyItemCreateDto);

            OkResult realOkResult = Assert.IsType<OkResult>(realActionResult.Result);
            Assert.Equal((new OkResult()).StatusCode, realOkResult.StatusCode);

            cartRepository.VerifyNoOtherCalls();
            itemRepository.Verify(a => a.AddItem(nonEmptyItemNoId), Times.Once);
            itemRepository.Verify(a => a.SaveChanges(), Times.Once);
            itemRepository.VerifyNoOtherCalls();
            messagePublisher.Verify(a => a.Publish("Item added to cart"), Times.Once);
            messagePublisher.VerifyNoOtherCalls();
            mapper.Verify(a => a.Map<Item>(nonEmptyItemCreateDto), Times.Once);
            mapper.VerifyNoOtherCalls();
        }
    }
}
